The `event_study_src` folder
============================================================================

The folder contains the complete codes from the `event_study` package. 
These codes are created during Lectures 9, 10, and 11. 

These codes are provided for your reference only. You should create these
modules yourself as you progress through the lectures.



```
toolkit/
|__ _dropbox/
|   |__ event_study/    <- Completed version of the event study (Lec 10,11)
|
|__ event_study/        <-- You should create this package yourself
|   |__ ...             <-- You should create the modules inside this pkg yourself
```


